/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<bits/stdc++.h>
using namespace std;
int is_prime(int num){
    int i;
    for(i=2;i<num;i++){
        if(num%i==0){
            return 0;
        }
    }
    if(num==i){
        return 1;
    }
    else{
        return 0;
    }
    
}
int is_armstrong(int num){
    int ld,onum,x;
    x=num;
    int sum=0;
    onum=num;
    int digits=0;
    while(x){
        x=x/10;
        digits++;
    }
    
    while(num){
        ld=num%10;
        sum+=pow(ld,digits);
        num=num/10;
    }
    if(onum==sum){
        return 1;
    }
    else{
        return 0;
    }
    
    
}
int is_perfect(int num){
    int sum=0,onum=num;
    for(int i=1;i<=num/2;i++){
        if(num%i==0){
            sum+=i;
        }
    }
    if(sum==onum){
        return 1;
    }
    else{
        return 0;
    }
    
}
int fact(int n){
    int result=1;
    for(int i=1;i<=n;i++){
        result=result*i;
    }
    return result;
}
int is_strong(int num){
    int sum=0,onum=num;
    while(num){
        int ld=num%10;
        sum+=fact(ld);
        num=num/10;
        
    }
    return sum==onum;
}

int main(){
    int num1,num2;
    cin>>num1>>num2;
    /*if(is_prime(num)){
        cout<<num<<" is a prime number"<<endl;
    }
    else{
        cout<<num<<" not a prime number"<<endl;
    }
    while(num1<=num2){
    if(is_armstrong(num1)){
        cout<<num1<<endl;
    }
    num1++;
    
    }
    if(is_perfect(num)){
        cout<<num<<" is a perfect number"<<endl;
    }
    else{
        cout<<num<<" not a perfect number"<<endl;
    }
    */
    while(num1<=num2){
        if(is_strong(num1)){
            cout<<num1<<endl;
        }
        num1++;
    }
    
    return 0;
}
