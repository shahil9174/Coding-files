/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
    long long num,n;
    int i,LastDigit,freq[10];
    cin>>num;
    for(i=0;i<10;i++){
        freq[i]=0;
    }
    n=num;
    while(n!=0){
        LastDigit=n%10;
        n=n/10;
        freq[LastDigit]++;
    }
    for(i=0;i<10;i++){
        cout<<"Frequency of "<<i<<"= "<<freq[i]<<endl;
    }

    return 0;
}