/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<bits/stdc++.h>
using namespace std;
int MSB(int num){
    int bits=sizeof(int);
    int msb=1<<(bits-1)*8;
    if(msb&num)
    return 1;
    else
    return 0;
}
int LSB(int num){
    if(num&1)
    return 1;
    else
    return 0;
}
int Nthbit(int num,int N){
    if((num>>N)&1)
    return 1;
    else
    return 0;
}
int Setbit(int num,int n){
    return (1<<n) | num;
}
int UnSetBit(int num,int n){
    return num & (~(1<<n));
}
int TaggleNthBit(int num,int n){
    return num ^ (1<<n);
}
int HighestorderBit(int num){
    int int_size=sizeof(int)*8;
    int order=-1;
    for(int i=0;i<int_size;i++){
        if((num>>i)&1)
        order=i;
    }
    if(order!=-1)
    return order;
    else
    return 0;
}
int LoweseOrderBit(int num){
    int int_size=sizeof(int)*8,order=0;
    for(int i=0;i<int_size;i++){
        if((num>>i)&1){
            order=i;
            break;
        }
    }
    return order;
}
int TrailingZeroes(int num){
    int int_size=sizeof(int)*8;
    int count =0;
    for(int i=0;i<int_size;i++){
        if((num>>i)&1){
            break;
        }
        count++;
        
    }
    return count;
}
int LeadingZeroes(int num){
    int int_size=sizeof(int)*8;
    int count=0;
    int msb=1<<(int_size-1);
    for(int i=0;i<int_size;i++){
        if((num<<i)&msb){
            break;
        }
        count++;
    }
    return count;
}
int flip(int num){
    return ~num;
}
void ZeroesOnes(int num){
    int int_size=sizeof(int)*8,zeroes=0,ones=0;
    for(int i=0;i<int_size;i++){
        if(num&1)
        ones++;
        else
        zeroes++;
        num=num>>1;
    }
    cout<<"ones="<<ones<<endl;
    cout<<"zeroes="<<zeroes<<endl;
}
int LeftRotate(int num,int rotation){
    int Dropped_msb,int_bits=sizeof(int)*8-1;
    while(rotation--){
        Dropped_msb=(num>>int_bits)&1;
        num=(num<<1) | Dropped_msb;
    }
    return num;
}
int RightRotate(int num,int Rotation){
    int Dropped_Lsb,int_bits=sizeof(int)*8-1;
    while(Rotation--){
        Dropped_Lsb=num&1;
        num=(num>>1) & (~(1<<int_bits));
        num=num | (Dropped_Lsb<<int_bits);
    }
    return num;
}
void DectoBin(int num){
    int int_size=sizeof(int)*8;
    int Bin[int_size];
    int Index=int_size-1;
    while(Index>=0){
        Bin[Index] = num & 1;
        Index--;
        num=num>>1;
    }
    for(int i=0;i<int_size;i++){
        cout<<Bin[i];
    }
}
void Swap(int n1,int n2){
    cout<<"Without Swapping"<<endl;
    cout<<"n1= "<<n1<<endl;
    cout<<"n2= "<<n2<<endl;
    n1=n1^n2;
    n2=n1^n2;
    n1=n1^n2;
    cout<<"After Swapping"<<endl;
    cout<<"n1= "<<n1<<endl;
    cout<<"n2= "<<n2<<endl;
    
}
void EvenOdd(int num){
    if(num & 1){
        cout<<num<<" is Odd";
    }
    else{
        cout<<num<<" is Even";
    }
}
int main()
{
   int num1,num2;
   cin>>num1;//>>num2;
   //cout<<MSB(n)<<endl;
  // ZeroesOnes(num);
  EvenOdd(num1);

    return 0;
}


