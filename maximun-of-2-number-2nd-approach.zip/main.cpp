/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>


using namespace std;

int main()
{
    char ch;
    cin>>ch;
    if((ch>='a' && ch<='z') || (ch>='A' && ch>='Z')){
        cout<<ch<<" is Alphabet";
    }
    else if(ch>='0' && ch<='9'){
        cout<<ch<<" is digit ";
    }
    else{
        cout<<ch<<" is a special character";
    }

    return 0;
}