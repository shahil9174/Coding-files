/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>


using namespace std;

int main()
{
    char ch;
    cin>>ch;
    if(ch>='a' && ch<='z') {
        cout<<ch<<" is a Lowercase";
    }
    else if(ch>='A' && ch<='Z'){
        cout<<ch<<" is a Uppercase ";
    }
    else{
        cout<<ch<<" is not a Alphabet";
    }

    return 0;
}