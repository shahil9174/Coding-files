/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>

using namespace std;
bool isArmstrong(int n)
{
    int org=n;
    int sum=0;
    while(n)
    {
        int ld=n%10;
        sum+=pow(ld,3);
        n=n/10;
        
    }
    if(org==sum)
    return true;
    else
    return false;
}

int main()
{
    int n;
    cin>>n;
    if(isArmstrong(n))
    cout<<"ArmStrong Number";
    else
    cout<<"Not a Armstrong number";

    return 0;
}