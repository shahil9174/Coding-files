#include <iostream>
#include<bits/stdc++.h>

using namespace std;

    int gcd(int a,int b){
    
    if(b==0){
        return a;
    }
    else{
        return gcd(b,b%a);
    }
    }
    int digit(int n){
        int count=0;
        while(n>0){
            n/=10;
            count++;
        }
        return count;
    }
    bool ispallindrome(int n){
        int org_num=n,res=0;
        while(n){
            int ld=n%10;
            res=res*10+ld;
            n/=10;
        }
        if(org_num==res){
            return true;
        }
        else{
            return false;
        }
    }
int factorial(int n){
    if(n==0){
        return 1;
    }
    return n*factorial(n-1);
}
int zerotrailing(int n){
    int res=0;
    while(n){
        res=res+n/5;
        n=n/5;
    }
    return res;
}

int main()
{
    int n;
    cin>>n;
    cout<<zerotrailing(n)<<endl;

    return 0;
}