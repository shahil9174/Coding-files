/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>

using namespace std;
void sieve(int n){
    vector<bool>isprime(n+1,true);
    for(int i=2;i*i<=n;i++){
        if(isprime[i]){
            for(int j=i*i;j<=n;j=j+i){
                isprime[j]=false;
            }
        }
    }
    for(int i=2;i<=n;i++){
        if(isprime[i]){
            cout<<i<<" ";
        }
    }
}
int power(int x,int n){
    int res=1;
    while(n>0){
        if(n%2!=0){
        res=res*x;
        }
        x=x*x;
        n=n/2;
    }
    return res;
}

int main()
{
   int x,n;
   cin>>x>>n;
   cout<<power(x,n)<<endl;
   //sieve(n);

    return 0;
}