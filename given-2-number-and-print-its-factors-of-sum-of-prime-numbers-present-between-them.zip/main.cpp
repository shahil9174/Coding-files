/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<bits/stdc++.h>
using namespace std;
int isprime(int num){
    int i;
    for(i=2;i<num;i++){
        if(num % i == 0)    
        {  
            return 0;  
        } 
    }
    
    if(i==num)
        return 1;
    else 
        return 0;
} 

void Factors(int num){
    for(int i=1;i<=num;i++){
      if(num%i==0){
          cout<<i<<" "; 
      }
    }
    
}

int main()
{
    int M,N,Sum=0;
    cin>>M>>N;
    while(M<=N){
        if(isprime(M)){
            Sum+=M;;
        }
        M++;
    }
    Factors(Sum);
    return 0;
    
}
