/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    char ch;
    cin>>ch;
    if(ch=='a'|| ch=='e'||ch=='i' || ch=='o' || ch=='u'){
        cout<<ch<<" is vowel";
    }
    else if((ch>='a' && ch<='z') ||(ch>='A' && ch<='Z')){
    cout<<ch<<" is consonant";
    }
    else{
        cout<<ch<<" is Not a Alphabet";
    }

    return 0;
}